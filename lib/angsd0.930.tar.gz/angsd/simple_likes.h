void call_simple(suint **counts,int *keepSites,double **lk,int nSites,int nSamples);
void simple_init();
void simple_destroy();
