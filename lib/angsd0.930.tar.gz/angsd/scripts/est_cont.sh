#!/bin/bash

echo "generate icnts file"
echo "run main cont analysis"
