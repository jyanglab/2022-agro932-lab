int bammer_main(argStruct *pars);
