#include "shared.h"
#include <vector>

void setArgsBam(argStruct *arguments);
void bamInfo(FILE *fp);
