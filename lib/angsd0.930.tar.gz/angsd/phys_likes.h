#include <vector>
void phys_init(std::vector<char*> bamnames);
void call_phys(chunkyT *chk,double **lk,int trim);
void phys_destroy();
