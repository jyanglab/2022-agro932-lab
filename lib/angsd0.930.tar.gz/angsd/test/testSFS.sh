#!/bin/bash
cd sfstest/
./sfstest.sh ../${1}

