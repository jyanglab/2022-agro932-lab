int saf_cat(int argc,char **argv);
int saf_check(int argc,char **argv);
