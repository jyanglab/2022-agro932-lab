maxTime <- 100

tk <- 1:maxTime


emis <- function(k){
    exp1 <- 

}
