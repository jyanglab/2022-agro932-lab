#include <vector>
#include "realSFS_shared.h"

template <typename T>
int main_dadi(int argc,char **argv);
