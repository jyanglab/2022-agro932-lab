void gatk_init();
void call_gatk(chunkyT *chk,double **lk,int trim);
void gatk_destroy();
