void bam_likes_init();
void call_bam(chunkyT *chk,double **likes,int trim);
void bam_likes_destroy();
